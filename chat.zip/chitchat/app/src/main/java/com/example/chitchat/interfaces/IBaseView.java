package com.example.chitchat.interfaces;

/**
 * 作为框架最基类的V层接口
 *
 */
public interface IBaseView {

    //定义一个方法用来显示提示
    void showTips(String msg);

}
