package com.example.chitchat.fragments.home;


import android.text.Layout;

import com.example.chitchat.R;
import com.example.chitchat.base.BaseFragment;
import com.example.chitchat.interfaces.IBasePersenter;

public class HomeFragment extends BaseFragment {
    @Override
    protected int getLayout() {
        return R.layout.fragment_home;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected IBasePersenter createPersenter() {
        return null;
    }
}
