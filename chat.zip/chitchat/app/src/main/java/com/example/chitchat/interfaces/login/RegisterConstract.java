package com.example.chitchat.interfaces.login;


import com.example.chitchat.interfaces.IBasePersenter;
import com.example.chitchat.interfaces.IBaseView;

public interface RegisterConstract {

    interface View extends IBaseView {
        //void getVerifyReturn(VerifyBean result);
    }

    interface Persenter extends IBasePersenter<View> {
        void getVerify();
    }

}
