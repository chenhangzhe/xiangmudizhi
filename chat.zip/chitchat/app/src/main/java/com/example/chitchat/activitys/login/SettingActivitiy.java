package com.example.chitchat.activitys.login;


import com.example.chitchat.base.BaseActivity;
import com.example.chitchat.interfaces.IBasePersenter;

public class SettingActivitiy extends BaseActivity {
    @Override
    protected int getLayout() {
        return 0;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected IBasePersenter createPersenter() {
        return null;
    }
}
