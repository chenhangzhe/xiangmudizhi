package com.example.chitchat.persenters.own;



import com.example.chitchat.base.BasePersenter;
import com.example.chitchat.common.CommonSubscriber;
import com.example.chitchat.interfaces.own.UserConstact;
import com.example.chitchat.module.HttpManager;
import com.example.chitchat.module.bean.DetailsUpdateBean;
import com.example.chitchat.module.bean.UserDetailsBean;
import com.example.chitchat.utils.RxUtils;

import java.util.Map;

public class DetailsPersenter extends BasePersenter<UserConstact.DetailsView> implements UserConstact.DetailsPersenter {
    @Override
    public void getDetails() {
        addSubscribe(HttpManager.getInstance().getChatApi().getUserDetails()
                .compose(RxUtils.rxScheduler())
                .subscribeWith(new CommonSubscriber<UserDetailsBean>(mView) {
                    @Override
                    public void onNext(UserDetailsBean result) {
                        mView.getDetailsReturn(result);
                    }
                }));
    }

    /**
     * 更新用户信息
     * @param map
     */
    @Override
    public void updateDetails(Map<String, String> map) {
        addSubscribe(HttpManager.getInstance().getChatApi().updateUserDetails(map)
                .compose(RxUtils.rxScheduler())
                .subscribeWith(new CommonSubscriber<DetailsUpdateBean>(mView) {
                    @Override
                    public void onNext(DetailsUpdateBean result) {
                        mView.updateDetailsReturn(result);
                    }
                }));
    }
}
