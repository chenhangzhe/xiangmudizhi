package com.example.chitchat.persenters.login;


import com.example.chitchat.base.BasePersenter;
import com.example.chitchat.common.CommonSubscriber;
import com.example.chitchat.interfaces.login.LoginConstract;
import com.example.chitchat.module.HttpManager;
import com.example.chitchat.module.bean.UserInfoBean;
import com.example.chitchat.utils.RxUtils;

public class LoginPersenter extends BasePersenter<LoginConstract.View> implements LoginConstract.Persenter {
    @Override
    public void login(String username, String password) {
        addSubscribe(HttpManager.getInstance().getChatApi().login(username, password)
                .compose(RxUtils.<UserInfoBean>rxScheduler())
                .subscribeWith(new CommonSubscriber<UserInfoBean>(mView) {
                    @Override
                    public void onNext(UserInfoBean userInfoBean) {
                        mView.loginReturn(userInfoBean);
                    }
                }));
    }
}
