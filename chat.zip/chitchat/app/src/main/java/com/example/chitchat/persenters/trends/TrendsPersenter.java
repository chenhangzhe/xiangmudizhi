package com.example.chitchat.persenters.trends;


import com.example.chitchat.base.BasePersenter;
import com.example.chitchat.common.CommonSubscriber;
import com.example.chitchat.interfaces.trends.TrendsStract;
import com.example.chitchat.module.HttpManager;
import com.example.chitchat.module.bean.PublishTrendsBean;
import com.example.chitchat.utils.RxUtils;

public class TrendsPersenter extends BasePersenter<TrendsStract.View> implements TrendsStract.Persenter {
    @Override
    public void sendTrends(String content, String resources) {
        addSubscribe(HttpManager.getInstance().getChatApi().sendTrends(content,resources)
                .compose(RxUtils.rxScheduler())
                .subscribeWith(new CommonSubscriber<PublishTrendsBean>(mView) {
                    @Override
                    public void onNext(PublishTrendsBean result) {
                        mView.sendTrendsReturn(result);
                    }
                }));
    }
}
