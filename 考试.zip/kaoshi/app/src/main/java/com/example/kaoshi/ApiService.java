package com.example.kaoshi;

import com.example.kaoshi.bean.Zhuantibean;

import io.reactivex.Flowable;
import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {
    //https://cdwan.cn/api/topic/list
    String URL = "https://cdwan.cn/api/topic/";

    @GET("api/topic/list")
    Observable<Zhuantibean> getdata(@Query("page") int page, @Query("size") int size);
}
