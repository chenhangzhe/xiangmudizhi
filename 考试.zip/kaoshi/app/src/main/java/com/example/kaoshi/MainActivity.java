package com.example.kaoshi;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.kaoshi.adapter.Fragment_Adapter;
import com.example.kaoshi.fragment.ShoucangFragment;
import com.example.kaoshi.fragment.ZhauntiFragment;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ViewPager main_vp;
    private TabLayout main_tab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        main_vp = (ViewPager) findViewById(R.id.main_vp);
        main_tab = (TabLayout) findViewById(R.id.main_tab);

        ArrayList<Fragment> list = new ArrayList<>();
        list.add(new ZhauntiFragment());
        list.add(new ShoucangFragment());
        Fragment_Adapter adapter = new Fragment_Adapter(getSupportFragmentManager(), this, list);
        main_vp.setAdapter(adapter);
        main_tab.setupWithViewPager(main_vp);
        main_tab.getTabAt(0).setText("专题").setIcon(R.drawable.ic_sort_selector);
        main_tab.getTabAt(1).setText("收藏").setIcon(R.drawable.ic_me_selector);

    }
}
