package com.example.kaoshi.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.kaoshi.R;
import com.example.kaoshi.bean.DataBean;

import java.util.List;

public class Recyadapter extends RecyclerView.Adapter<Recyadapter.ViewHolder> {
    private Context context;
    private List<DataBean> list;

    public Recyadapter(Context context, List<DataBean> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = View.inflate(context, R.layout.item_zhaunti, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DataBean bean = list.get(position);
        Glide.with(context).load(bean.getScene_pic_url()).into(holder.img);
        holder.title.setText(bean.getTitle());
        holder.subtitle.setText(bean.getSubtitle());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView img;
        private TextView title;
        private TextView subtitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.img_rv_zhuanti);
            title = itemView.findViewById(R.id.title_zhaunti);
            subtitle = itemView.findViewById(R.id.subtitle);
        }
    }
}
