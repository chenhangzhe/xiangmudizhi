package com.example.kaoshi.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kaoshi.R;
import com.example.kaoshi.adapter.Recyadapter;
import com.example.kaoshi.bean.DataBean;
import com.example.kaoshi.p.Zhaunti_Presenter;
import com.example.kaoshi.v.Zhuanti_view;

import java.util.ArrayList;
import java.util.List;

public class ZhauntiFragment extends Fragment implements Zhuanti_view {

    private RecyclerView recy;
    private ArrayList<DataBean> dataBeans;
    private Recyadapter recyadapter;
    private Zhaunti_Presenter presenter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.zhuanti_view, null);
        initView(view);

        presenter = new Zhaunti_Presenter(this);
        presenter.getdata();
        return view;
    }

    private void initView(View view) {
        recy = view.findViewById(R.id.zhuan_recy);
        recy.setLayoutManager(new LinearLayoutManager(getActivity()));
        dataBeans = new ArrayList<>();
        recyadapter = new Recyadapter(getActivity(), dataBeans);
        recy.setAdapter(recyadapter);
    }

    @Override
    public void getdata(List<DataBean> result) {
        dataBeans.addAll(result);
        recyadapter.notifyDataSetChanged();
    }

    @Override
    public void getString(String str) {

    }
}
