package com.example.kaoshi.m;

import com.example.kaoshi.ApiService;
import com.example.kaoshi.Callback;
import com.example.kaoshi.bean.DataBean;
import com.example.kaoshi.bean.Zhuantibean;
import com.example.kaoshi.p.Zhaunti_Presenter;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class Zhuanti_moudel {
    public void getdata(final Callback callback) {
        Retrofit build = new Retrofit.Builder()
                .baseUrl(ApiService.URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();
        ApiService apiService = build.create(ApiService.class);
        Observable<Zhuantibean> getdata = apiService.getdata(1,10);
        getdata.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<Zhuantibean>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(Zhuantibean bean) {
                        List<DataBean> data = bean.getData().getData();
                        callback.Onreccsess(data);
                    }

                    @Override
                    public void onError(Throwable e) {
                        callback.OnFail(e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                });

    }
}
