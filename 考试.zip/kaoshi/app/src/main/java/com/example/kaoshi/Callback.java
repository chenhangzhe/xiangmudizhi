package com.example.kaoshi;

import com.example.kaoshi.bean.DataBean;

import java.util.List;

public interface Callback {
    void Onreccsess(List<DataBean> list);
    void OnFail(String str);
}
