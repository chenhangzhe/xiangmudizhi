package com.example.kaoshi.p;

import com.example.kaoshi.Callback;
import com.example.kaoshi.bean.DataBean;
import com.example.kaoshi.m.Zhuanti_moudel;
import com.example.kaoshi.v.Zhuanti_view;

import java.util.List;

public class Zhaunti_Presenter implements Callback {
    private Zhuanti_view view;
    private Zhuanti_moudel moudel;

    public Zhaunti_Presenter(Zhuanti_view view) {
        this.view = view;
        moudel =new Zhuanti_moudel();
    }

    public void getdata() {
        moudel.getdata(this);
    }

    @Override
    public void Onreccsess(List<DataBean> list) {
        view.getdata(list);
    }

    @Override
    public void OnFail(String str) {
        view.getString(str);
    }
}
