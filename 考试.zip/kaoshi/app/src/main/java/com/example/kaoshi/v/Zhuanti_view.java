package com.example.kaoshi.v;

import com.example.kaoshi.bean.DataBean;
import com.example.kaoshi.bean.Zhuantibean;

import java.util.List;

public interface Zhuanti_view {
    void getdata(List<DataBean> result);
    void getString(String str);
}
